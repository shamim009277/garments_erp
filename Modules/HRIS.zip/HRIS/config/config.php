<?php

return [
    'name' => 'HRIS',
];
