<?php

return [
    'name' => 'Sample',
];
