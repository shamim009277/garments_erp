<?php

return [
    'name' => 'Payroll',
];
