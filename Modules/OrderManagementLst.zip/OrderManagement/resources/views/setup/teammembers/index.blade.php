@extends('layouts.app')
@section('title', 'Order Management')
@section('content')
    <div class="row">
        <div class="col-12">
            @include('components.breadcrumb', [
                'title' => 'Order Management',
                'subtitle' => 'Team Members',
                'breadcrumbs' => [
                    ['label' => 'Order Management', 'url' => route('ordermanagement.index')],
                    ['label' => 'Setup', 'url' => route('ordermanagement.index')],
                    ['label' => 'Team Members', 'url' => route('ordermanagement.setup.teammembers.index')],
                ],
            ])
        </div>
        <div class="col-md-8">
            <div class="card alert-primary alert-top-border padding-card">
                <div class="card-header">
                    <h6 class="my-0 text-primary"> <i data-feather="list" width="16" height="16"></i> Team Members List
                    </h6>
                </div>
                <div class="card-body">
                    <table id="datatable" class="table table-bordered dt-responsive  nowrap w-100" width="100%">
                        <thead>
                            <tr>
                                <th width="5%">#</th>
                                <th width="25%">Team</th>
                                <th width="25%">Merchant</th>
                                <th width="15%">Leader</th>
                                <th width="15%">Assistant</th>
                                <th width="10%">Status</th>
                                <th width="10%">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($teamMembers as $key => $teamMember)
                                <tr>
                                    <td width="5%">{{ $key + 1 }}</td>
                                    <td width="25%">{{ $teamMember->team->team_name ?? 'N/A' }}</td>
                                    <td width="25%">{{ $teamMember->merchant->name ?? 'N/A' }}</td>
                                    <td width="15%">
                                        <span class="badge bg-{{ $teamMember->is_leader ? 'success' : 'secondary' }}">
                                            {{ $teamMember->is_leader ? 'Yes' : 'No' }}
                                        </span>
                                    </td>
                                    <td width="15%">
                                        <span class="badge bg-{{ $teamMember->is_assistant ? 'info' : 'secondary' }}">
                                            {{ $teamMember->is_assistant ? 'Yes' : 'No' }}
                                        </span>
                                    </td>
                                    <td class="text-center">
                                        <p class="text-{{ $teamMember->is_active ? 'success' : 'danger' }}">
                                            {{ $teamMember->is_active ? 'Active' : 'Inactive' }}</p>
                                    </td>
                                    <td>
                                        <a href="#" class="btn btn-soft-success waves-effect waves-light"
                                            style="padding: 4px 6px;" data-bs-toggle="modal"
                                            data-bs-target="#editModal{{ $teamMember->id }}"><i class="fas fa-edit"></i></a>
                                        <form action="{{ route('ordermanagement.setup.teammembers.destroy', $teamMember->id) }}"
                                            method="POST" class="d-inline">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="btn btn-sm btn-danger"
                                                onclick="return confirm('Are you sure you want to delete this team member?')">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                                {{-- load edit modal --}}
                                <div class="modal fade" id="editModal{{ $teamMember->id }}" tabindex="-1"
                                    aria-labelledby="editModalLabel{{ $teamMember->id }}" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="editModalLabel{{ $teamMember->id }}">Edit Team Member
                                                </h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <form id="moduleForm"
                                                    action="{{ route('ordermanagement.setup.teammembers.update', $teamMember->id) }}"
                                                    method="POST">
                                                    @csrf
                                                    @method('PUT')
                                                    <div class="row">
                                                        <div class="col-md-12">
                                                            <x-select-input-group name="team_id" label="Team"
                                                                :options="$teams->pluck('team_name', 'id')" :selected="$teamMember->team_id??old('team_id')" required />
                                                        </div>
                                                        <div class="col-md-12">
                                                            <x-select-input-group name="merchant_id" label="Merchant"
                                                                :options="$merchants->pluck('name', 'id')" :selected="$teamMember->merchant_id??old('merchant_id')" required />
                                                        </div>
                                                        <div class="col-md-6">
                                                            <x-select-input-group name="is_leader" label="Is Leader?"
                                                                :options="['1' => 'Yes', '0' => 'No']" :selected="$teamMember->is_leader ? '1' : '0'" required />
                                                        </div>
                                                        <div class="col-md-6">
                                                            <x-select-input-group name="is_assistant" label="Is Assistant?"
                                                                :options="['1' => 'Yes', '0' => 'No']" :selected="$teamMember->is_assistant ? '1' : '0'" required />
                                                        </div>
                                                        <div class="col-md-12">
                                                            <x-select-input-group name="is_active" label="Is Active?"
                                                                :options="['1' => 'Active', '0' => 'Inactive']" :selected="$teamMember->is_active ? '1' : '0'" required />
                                                        </div>
                                                    </div>
                                                    <x-primary-button
                                                        class="float-start btn-sm submitBtn">Save</x-primary-button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card alert-info alert-top-border">
                <div class="card-header">
                    <h6 class="my-0 text-primary"> <i class="mdi mdi-list"></i> Input Parameters For New Team Member ...
                    </h6>
                </div>
                <div class="card-body">
                    <form id="moduleForm" action="{{ route('ordermanagement.setup.teammembers.store') }}" method="POST">
                        @csrf
                        <x-select-input-group name="team_id" label="Team" :options="$teams->pluck('team_name', 'id')" :selected="old('team_id')" required />
                        <x-select-input-group name="merchant_id" label="Merchant" :options="$merchants->pluck('name', 'id')" :selected="old('merchant_id')" required />
                        <x-select-input-group name="is_leader" label="Is Leader?" :options="['1' => 'Yes', '0' => 'No']" :selected="old('is_leader', '0')" required />
                        <x-select-input-group name="is_assistant" label="Is Assistant?" :options="['1' => 'Yes', '0' => 'No']" :selected="old('is_assistant', '0')" required />
                        <x-select-input-group name="is_active" label="Is Active?" :options="['1' => 'Active', '0' => 'Inactive']" :selected="old('is_active', '1')" required />
                        <x-primary-button class="float-start btn-sm submitBtn">Save</x-primary-button>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection

@push('scripts')
    <script>
        $(document).ready(function() {
            // Add any specific JavaScript for Team Members if needed
        });
    </script>
@endpush
