<?php

namespace Modules\OrderManagement\Http\Controllers\Setup;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\OrderManagement\Models\Setup\TeamMember;
use Modules\OrderManagement\Models\Setup\Team;
use Modules\HRIS\Models\Database\Employee;
use Modules\OrderManagement\Http\Requests\Setup\TeamMemberRequest;
use Illuminate\Support\Facades\DB;
use App\Traits\ToggleStatus;
use Illuminate\Support\Facades\Auth;

class TeamMemberController extends Controller
{
    use ToggleStatus;
    
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $teamMembers = TeamMember::with(['team', 'merchant'])->get();
        $teams = Team::all();
        $merchants = Employee::all();
        return view('ordermanagement::setup.teammembers.index', compact('teamMembers', 'teams', 'merchants'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $teams = Team::all();
        $merchants = Employee::all();
        return view('ordermanagement::setup.teammembers.create', compact('teams', 'merchants'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(TeamMemberRequest $request)
    {
        DB::beginTransaction();
        try {
            TeamMember::create([
                'team_id' => $request->team_id,
                'merchant_id' => $request->merchant_id,
                'is_leader' => $request->is_leader,
                'is_assistant' => $request->is_assistant,
                'is_active' => $request->is_active,
            ]);
            
            DB::commit();
            return redirect()->route('ordermanagement.setup.teammembers.index')->with('success', 'Team Member created successfully');
        } catch (\Exception $e) {
            DB::rollBack();
            return redirect()->back()->with('error', 'Failed to create team member: ' . $e->getMessage());
        }
    }

    /**
     * Show the specified resource.
     */
    public function show($id)
    {
        $teamMember = TeamMember::with(['team', 'merchant'])->findOrFail($id);
        return view('ordermanagement::setup.teammembers.show', compact('teamMember'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        $teamMember = TeamMember::findOrFail($id);
        $teams = Team::all();
        $merchants = Employee::all();
        return view('ordermanagement::setup.teammembers.edit', compact('teamMember', 'teams', 'merchants'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(TeamMemberRequest $request, $id)
    {
        DB::beginTransaction();
        try {
            $teamMember = TeamMember::findOrFail($id);
            $teamMember->update([
                'team_id' => $request->team_id,
                'merchant_id' => $request->merchant_id,
                'is_leader' => $request->is_leader,
                'is_assistant' => $request->is_assistant,
                'is_active' => $request->is_active,
            ]);
            
            DB::commit();
            return redirect()->route('ordermanagement.setup.teammembers.index')->with('success', 'Team Member updated successfully');
        } catch (\Exception $e) {
            DB::rollBack();
            return redirect()->back()->with('error', 'Failed to update team member: ' . $e->getMessage());
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        DB::beginTransaction();
        try {
            $teamMember = TeamMember::findOrFail($id);
            $teamMember->delete();
            DB::commit();
            return redirect()->route('ordermanagement.setup.teammembers.index')->with('success', 'Team Member deleted successfully');
        } catch (\Exception $e) {
            DB::rollBack();
            return redirect()->back()->with('error', 'Failed to delete team member: ' . $e->getMessage());
        }
    }
}
