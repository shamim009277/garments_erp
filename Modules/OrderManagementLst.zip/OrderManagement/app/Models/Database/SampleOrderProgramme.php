<?php

namespace Modules\OrderManagement\Models\Database;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Support\Facades\Auth;
use Modules\OrderManagement\Models\Database\InitialOrder;
use Modules\OrderManagement\Models\Setup\Color;
use Modules\OrderManagement\Models\Setup\SampleType;
use Modules\OrderManagement\Models\Setup\Composition;
use Modules\OrderManagement\Models\Setup\Item;
use Modules\OrderManagement\Models\Setup\FabricTreatments;
use Modules\OrderManagement\Models\Setup\Size;

class SampleOrderProgramme extends Model
{
    use HasFactory;

    protected $table = 'om_database_sample_order_programme';
    protected $guarded = [];

    protected static function booted()
    {
        static::created(function ($model) {
            $model->created_by = Auth::id();
        });

        static::updated(function ($model) {
            $model->updated_by = Auth::id();
        });
    }

    public function initialOrder()
    {
        return $this->belongsTo(InitialOrder::class, 'initial_order_id');
    }

    public function color()
    {
        return $this->belongsTo(Color::class, 'color_id');
    }

    public function sampleType()
    {
        return $this->belongsTo(SampleType::class, 'sample_type_id');
    }

    public function composition()
    {
        return $this->belongsTo(Composition::class, 'composition_id');
    }

    public function item()
    {
        return $this->belongsTo(Item::class, 'item_id');
    }

    public function fabricTreatment()
    {
        return $this->belongsTo(FabricTreatments::class, 'fabric_treatment_id');
    }

    public function size()
    {
        return $this->belongsTo(Size::class, 'size_id');
    }
}
